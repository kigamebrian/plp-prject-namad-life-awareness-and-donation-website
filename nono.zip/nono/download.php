<?php
include 'inc/init.php';
if(isset($_GET['down'])){
  $path= $_GET['down'];
  $res =mysqli_query($connection,"SELECT * FROM documents WHERE path='$path'");

  header('Content-type: application/octet-stream');
  header('Content-Disposition: attachment; filename="'.basename($path).'"');
  header('Content-length:' .filesize($path));
  readfile($path);


}



 ?>
