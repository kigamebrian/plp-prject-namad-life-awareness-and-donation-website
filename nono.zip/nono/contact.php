<?php include 'includes/header.php' ?>
<div class="container-wrapper">

<?php include 'includes/navigation.php' ?>

<!--banner area-->
<div class="section banner-page" data-background="imgs/bunner-single.jpg" style="background-image: url(&quot;imgs/bunner.jpg&quot;);">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page">Contact</div>
			</div>
			<div class="d-flex justify-content-center bd-highlight mb-3">
			    <nav aria-label="breadcrumb">
				  <ol class="breadcrumb ">
				    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
				    <li class="breadcrumb-item active" aria-current="page">Contact</li>
				  </ol>
				</nav>
		  	</div>
		</div>
	</div>
<!--content area -->
<div class="section">
		<div class="content-wrap">
			<div class="container1">
				<div class="row">
					<div class="col-sm-6 col-md-6">
						<h2 class="section-heading text-center">
							Send a <span>Message</span>
							<hr>
						</h2>
						<div class="margin-bottom-50"></div>

						<div class="content">
							<form action="contact.php" name="contact-form" class="contact-form" id="contact-form"  role="form"  method="post">
								<div class="row">
									<div class="col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="name" class="form-control" id="p_name" placeholder="Enter Name" required="required" data-error="Name is required.">
											<div class="help-block with-errors"></div>
										</div>
									</div>
									<div class="col-sm-6 col-md-6">
										<div class="form-group">
											<input type="email" name="email" class="form-control" id="p_email" placeholder="Enter Email" required="required" data-error="Enter a valid email ">
											<div class="help-block with-errors"></div>
										</div>
									</div>
									<div class="col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="subject" class="form-control" id="p_subject" placeholder="Subject" required="required" data-error="Subject is required">
											<div class="help-block with-errors"></div>
										</div>
									</div>
									<div class="col-sm-6 col-md-6">
										<div class="form-group">
											<input type="text" name="phone" class="form-control" id="p_phone" placeholder="Enter Phone Number">
											<div class="help-block with-errors"></div>
										</div>
									</div>
								</div>
								<div class="form-group">
									 <textarea id="p_message" name="message" class="form-control" rows="6" placeholder="Enter Your Message"></textarea>
									<div class="help-block with-errors"></div>
								</div>
								<div class="form-group">
									<div id="success"></div>
									<button type="submit" name="submit" class="btn btn-primary disabled" id="submit_form"style="pointer-events: all; cursor: pointer;">SEND MESSAGE</button>

									<img src="imgs/spinner.gif" id="loading-img">
								</div>
							</form>
							<div class="response_msg"></div>
							<div class="margin-bottom-50"></div>
						 </div>
					</div>

				<div class="col-sm-4 col-md-4" id="address">
						<h2 class="section-heading text-center">
							Contact details
							<hr>
						</h2>
							<div class="text-center add">
						<div class="rs-icon-info">
							<div class="info-icon">
								<i class="fa fa-map-marker"></i>
							</div>
							<div class="info-text"> upperhill  Nairobi</div>
						</div>

						<div class="rs-icon-info">
							<div class="info-icon">
								<i class="fa fa-envelope"></i>
							</div>
							<div class="info-text">Nobilityke@gmail.com</div>
						</div>

						<div class="rs-icon-info">
							<div class="info-icon">
								<i class="fa fa-phone"></i>
							</div>
							<div class="info-text">(+254)768989916</div>
						</div>
					</div>

					</div>

					<div class="clearfix"></div>



				</div>

			</div>
		</div>
	</div>
</div>
<hr>
<?php include  'includes/footer.php';?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
$(document).ready(function(){
$("#contact-form").on("submit",function(e){
e.preventDefault();
if($("#contact-form [name='name']").val() === '')
		{
		$("#contact-form [name='name']").css("border","1px solid red");
		}
   else if ($("#contactform [name='email']").val() === '')
		{
		$("#contact-form [name='email']").css("border","1px solid red");
		}
else
{
	$("#loading-img").css("display","block");
	var sendData = $( this ).serialize();
	$.ajax({
	type: "POST",
	url: "assets/get_response.php",
	data: sendData,
	success: function(data){
	    $("#loading-img").css("display","none");
	    $(".response_msg").text(data);
	   $(".response_msg").slideDown().fadeOut(3000);
	    $("#contact-form").find("input[type=text], input[type=email], textarea").val("");
	     }
	  });
	 }
});
$("#contact-form input").blur(function(){
    var checkValue = $(this).val();
    if(checkValue != '')
  {
    $(this).css("border","1px solid #eeeeee");
   }
  });
});
</script>
</body>
<html>
