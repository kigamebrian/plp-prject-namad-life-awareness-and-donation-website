<?php include 'includes/header.php' ?>
<div class="container-wrapper">

<?php include 'includes/navigation.php' ?>


<!--banner area-->
<div class="section banner-page" data-background="imgs/bunner-single.jpg" style="background-image: url(&quot;imgs/bunner.jpg&quot;);">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page">OUr Team</div>
			</div>
			<div class="d-flex justify-content-center bd-highlight mb-3">
			    <nav aria-label="breadcrumb">
				  <ol class="breadcrumb ">
				    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
				    <li class="breadcrumb-item active" aria-current="page">Our Team</li>
				  </ol>
				</nav>
		  	</div>
		</div>
	</div>
<div class="section">
  <div class="content-wrap">
    <div class="contain">
			<div class="row ">


			<?php
			$query = "SELECT * FROM members ORDER BY id DESC";
			$result =  $connection->query($query);

			while ($row = mysqli_fetch_assoc($result)) {

					$member_id = $row['id'];
					$member_name = substr($row['name'],0,50);
					$member_position= $row['position'];
					$member_bio= substr($row['bio'],0,500);
					$member_photo= $row['member_picture'];


			 ?>
			 	<div class="col-md-4 form-group">


								<div class="flip-card">
									  <div class="flip-card-inner">
									    <div class="flip-card-front">
									      <img src="admin/<?=$member_photo;?>" alt="<?=$member_name;?>" style="width:300px;height:300px;">
									    </div>
									    <div class="flip-card-back">
									      <h3><?=$member_name;?></h3>
									      <p><i><?=$member_position;?></i></p>
									      <p><?=$member_bio;?></p>
									    </div>
									  </div>
										<hr>
										<br>
									</div>
	 							</div>

					<?php

				}

				 ?>
			 </div>
			 <hr>
				<br>

              <div class="row">

					<div class="cta-info">
						<h1 class="section-heading center">
							Nobility Of<span> Nature</span> Organiation
						</h1>
						<p>Teritatis et quasi architecto. Sed ut perspiciatis unde omnis iste natus error</p>
						<div class="spacer-50"></div>
						<a href="Aboutus.php" class="btn btn-primary margin-btn">LEARN MORE</a> <a href="#" class="btn btn-secondary margin-btn">JOIN US NOW</a>
					</div>

				</div>
    </div>

  </div>

</div>
<div class="section cta">
		<div class="content-wrap-20">
			<div class="contain">
				<div class="row">
					<div class="col-sm-12 col-md-12">
						<div class="cta-1">
			              	<div class="body-text">
			                	<h3> “Every person is defined by the communities she belongs to.” –Orson Scott Card</h3>
			              	</div>
			              	<div class="body-action">
			                	<a href="#" class="btn btn-secondary">DONATE NOW</a>
			              	</div>
			            </div>
					</div>
				</div>
			</div>
		</div>
	</div>
  <?php include 'includes/footer.php';?>
</div>
  <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous">
</body>
</html>
