<?php
$ab=$_POST['category'];

echo $ab;
header( "Location:viewsgimages.php?ids=$ab" );
?>
