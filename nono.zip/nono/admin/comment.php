<!--brian kigame-->
<?php
include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}
 if(isset($_GET['del_com']) && $_GET['del_com'] !== ''){
   $d_id=$_GET['del_com'];
  if( delete('comment','id',$d_id)){
    header("Location:comment.php");
  }
 }
 //approve comment
 if(isset($_GET['app']) && $_GET['app'] !== ''){
   $app= $_GET['app'];
   if(confirm($app)){
     header("Location:comment.php");
   }
 }
 //unapprove comment
 if(isset($_GET['unapp']) && $_GET['unapp'] !== ''){
   $unapp= $_GET['unapp'];
   if(confirm($unapp)){
     header("Location:comment.php");
   }
 }
?>

    <div id="wrapper">

        <!-- Navigation -->
       <?php include 'includes/navigation.php'; ?>


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                          <h1 class="page-header text-center">
                            Welcome to the Administration Panel
                        </h1>
                        <div class="panel panel-default">

                              <div class="panel-heading">
                                <i>All comments </i>
                              </div>
                        <div class="table-responsive">
                          <table class="table table-striped table-hover table-bordered">
                            <thead>
                              <th>ID</th>
                              <th>Name</th>
                              <th>Email</th>
                              <th>Body</th>
                              <th>Status</th>
                              <th>Post ID</th>
                              <th>Comment Date</th>
                              <?php if($permissions === "Admin"){
                                echo '<th colspan="3" class="text-center">Action</th>';
                              } ?>

                            </thead>
                            <tbody>
                              <?php
                                require '../classes/comment.php';
                                $comment_obj = new Comment($connection);
                                $comment_obj->getComments();
                              ?>
                            </tbody>
                          </table>
                        </div>
                    </div>
                  </div>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
