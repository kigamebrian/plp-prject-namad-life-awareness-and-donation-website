<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}

$id =$_SESSION['login_user'];
$query =mysqli_query($connection,"SELECT * FROM users WHERE id=$id");
$record =mysqli_fetch_array($query);
$hashed =$record['pasword'];
$old_password=((isset($_POST['old_password']))?sanitize($_POST['old_password']):'');
$old_password=trim($old_password);
$password=((isset($_POST['new_password']))?sanitize($_POST['new_password']):'');
$password=trim($password);
$confirm=((isset($_POST['confirm']))?sanitize($_POST['confirm']):'');
$confirm=trim($confirm);
$new_hashed =password_hash($password, PASSWORD_DEFAULT);
$errors= array();
?>

<div id="wrapper">

    <!-- Navigation -->
    <?php include 'includes/navigation.php'; ?>


    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
                <h3>Change password </h3>
                <br>

                    <div class="col-md-6">
                <?php
                      if($_POST){
                        //form validation
                        $uppercase = preg_match('@[A-Z]@', $password);
                        $lowercase = preg_match('@[a-z]@', $password);
                        $number    = preg_match('@[0-9]@', $password);
                        $specialChars = preg_match('@[^\w]@', $password);
                        if(empty($_POST['old_password']) || empty($_POST['new_password']) || empty($_POST['confirm'])){
                          $errors[]='You must fill out all fields.';
                        }

                      
                        if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
                            $errors[]='Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
                      }
                        //if new pass matches confirm
                        if ($password != $confirm){
                          $errors[]='The new password does not match !';
                        }
                        if(!password_verify($old_password,$hashed)){
                          $errors[]='your old password is incorect';

                        }

                        //check for errors
                        if(!empty($errors)){
                          echo display_errors($errors);
                        }else{
                          //change password
                          $connection->query("UPDATE users SET pasword = '$new_hashed' WHERE id= '$id'");
                          $_SESSION['success_flash']='Password updated successfully';
                          header('Location: profile.php');



                        }

                      }
                      ?>


                        <form action="change_password.php" method="post">
                            <div class="form-group">
                                <label for="old_password">Old Password</label>
                                <input type="password" name="old_password" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="new_password">New Password</label>
                                <input type="password" name="new_password" class="form-control" >
                            </div>
                            <div class="form-group">
                                <label for="confirm">Confirm New Password</label>
                                <input type="password" name="confirm" class="form-control" >
                            </div>
                            <div class="form-group">
                                <input type="submit" name="" class="btn btn-success" value="Update your password">
                            </div>
                        </form>
                        </div>


            <!-- /.row -->

        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
