<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';

function add_member(){
global $connection;
if (isset($_POST['submit'])) {
  $name = sanitize($_POST['name']);
  $position =sanitize($_POST['position']);
  $bio =sanitize($_POST['bio']);
  $errors= array();
  if (isset($_FILES['photo'])) {
    $image = $_FILES['photo']['name'];
    $ImageName = time() . '-' . $_FILES["photo"]["name"];
    $target_dir= "team/";
    $target_file = $target_dir . basename($ImageName);
    $fileType = pathinfo($target_file,PATHINFO_EXTENSION);
    $allowTypes = array('jpg','png','jpeg','gif');
    if($_FILES['photo']['size'] > 200000) {
      $errors = "Image size should not be greated than 200Kb";

    }
    if(file_exists($target_file)) {
      $errors[]= "File already exists";

    }
    elseif(!in_array($fileType, $allowTypes))
    {
      $errors[] = "Sorry, only JPG, JPEG, PNG & GIF files are allowed to upload";

}
    // Upload image only if no errors
    if (empty($error)) {
      if(move_uploaded_file($_FILES["photo"]["tmp_name"],$target_file)) {
      $_SESSION['success_flash']='image uploaded successfully';
    } else {
      $errors[] = "There was an error in the database";

    }
  }
}


  $query = "INSERT INTO members(name,position,bio,member_picture)
  VALUES('$name','$position','$bio','$target_file')";

  $result = mysqli_query($connection, $query);

  if (!$result) {
    die("Could not send data " . mysqli_error($connection));
    }
  else{
    header("Location: viewteam.php?member_added");
  }


}

}
add_member();

?>
