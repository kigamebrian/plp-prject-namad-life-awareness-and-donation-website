<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}


?>
<style type="text/css">


img {
max-width: 100%;
max-height: 100%;
}

</style>
    <div id="wrapper">

        <!-- Navigation -->
       <?php include 'includes/navigation.php'; ?>


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">

                        <h1 class="page-header text-center">
                            Welcome to the Administration Panel
                        </h1>
					<div class="col-sm-4">
            <?php if (!empty($msg)): ?>
              <div class="alert <?php echo $msg_class ?>" role="alert">
                <?php echo $msg; ?>
              </div>
            <?php endif; ?>

            <h4 class="text-center"> Add Events</h4>
						<form action="eventadd.php" method="post" enctype="multipart/form-data">
							<div class="form-group">
								<input type="text" name="title" placeholder=" event title" class="form-control" required="">
							</div>
              <div class="form-group">
                <textarea type="text" name="description" placeholder="Event description" class="form-control" required="" rows="6"></textarea>
              </div>
              <div class="form-group">
                <label for="datepicker">Event Date:</label>
               <input type="date" id="datepicker" name='date' size='9' value="" class="form-control" required="" />
              </div>
              <div class="form-group">
              <div class="row">
              <div class="col-sm-3"
              <label for="start-time">Start time</label>
              <input type="time" name="start_time" class="form-control" placeholder="Select time" required="">
             </div>
             <div class="col-sm-3"
             <label for="start-time">End time</label>
             <input type="time" name="end_time" class="form-control" placeholder="Select time" required="" >
            </div>
              </div>
            </div>
            <div class="form-group">

              <input type="text" name="venue" placeholder="Venue" class="form-control" required="">
            </div>
            <div class="form-group ">
              <div class="row">
                <div class="col-sm-6">
                  <label for="image">Image/Poster</label>
                  <input type="file" name="Eimage"  class="form-control" id="chooseFile" required>
                </div>
                <div class="col-sm-6">
                  <div class="user-image mb-3 text-center">
                     <div style=" overflow: hidden; background: #cccccc; margin: 0 auto">
                       <img src="..." class="figure-img img-fluid rounded" id="imgPlaceholder" alt="">
                     </div>
                   </div>

                </div>
                </div>
            </div>
							<div class="form-group">
								<input type="submit" name="event_add" value="Add Event" class="btn btn-primary">
							</div>
						</form>

						</div>
               	<div class="col-sm-8">
                  <h4 class="text-center">Events</h4>
               <table class="table table-bordered table-striped table-hover">
                 <thead>
                   <th>Event</th>
                   <th>Date</th>
                    <th>Start time</th>
                    <th>Delete Event</th>
                 </thead>

                 <tbody>
                   <?php show_Event(); ?>
                 </tbody>
               </table>
						</div>
                <!-- /.row -->
            </div>
        </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <script>
        function readURL(input) {
          if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
              $('#imgPlaceholder').attr('src', e.target.result);
            }

            // base64 string conversion
            reader.readAsDataURL(input.files[0]);
          }
        }

        $("#chooseFile").change(function () {
          readURL(this);
        });
    </script>

</body>

</html>
