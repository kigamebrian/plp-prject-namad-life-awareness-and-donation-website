<?php include 'includes/header.php';?>
<style media="screen">
  body{
    background-color: #FFFFFF;
    background-size:100vh 100vw;
    background-attachment: fixed;

  }
  #signup-form{
    width: 60%;
    height: 80%;
    border: 2px solid #000;
    border-radius: 15px;
    box-shadow: 7px 7px 15px rgba(0,6,0,6);
    margin: 8% auto;
    padding: 15px;
    background-color: #fff;
  }
</style>

<section class="signup">
  <div class="container">
      <div class="signup-content" id="signup-form" >
<?php require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';
if(isset($_POST['signup'])){
  $fname=((isset($_POST['fname']))?sanitize($_POST['fname']):'');
  $username=((isset($_POST['uname']))?sanitize($_POST['uname']):'');
  $email=((isset($_POST['email']))?sanitize($_POST['email']):'');
  $password=$_POST['psw'];
  $confirm=$_POST['rpsw'];
  $permissions="Admin";
  $date = date("Y-m-d H:i:s");
  $errors =array();
  if($_POST){
    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);
    $number    = preg_match('@[0-9]@', $password);
    $specialChars = preg_match('@[^\w]@', $password);

    $emailQuery =$connection->query("SELECT * FROM users WHERE email='$email'");
    $emailCount=mysqli_num_rows($emailQuery);

    if($emailCount !=0){
      $errors[]='that email already exists';
    }

    $required=array('fname','email','uname','psw','rpsw');
    foreach($required as $f){
      if(empty($_POST[$f])){
        $errors[]='Please fill all fields !';
        break;
      }
    }


  if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
      $errors[]='Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
}
    if ($password != $confirm){
      $errors[]='Your password do not match';
    }
    if (!filter_var($email,FILTER_VALIDATE_EMAIL)){
      $errors[] ='enter a valid email';
    }



    if(!empty($errors)){
      echo display_errors($errors);

    }
else{
  $rand =rand(1,3);
  switch($rand){
    case "1";
    $profile_pic="users/profile_pics/defaults/head_1.png";
    break;
    case "2";
    $profile_pic="users/profile_pics/defaults/head_2.png";
    case "3";
    $profile_pic="users/profile_pics/defaults/head_1.png";
    break;
  }
  $hashed=password_hash($password,PASSWORD_DEFAULT);
  $sql="INSERT INTO  users (full_name,username,email,pasword,profile_pic,permissions) VALUES ('$fname','$username','$email','$hashed','$profile_pic','$permissions')";
  if ($connection->query($sql) === TRUE) {
     echo "New record created successfully";
     header("Location:login.php");
  } else {
    echo "Error: " . $sql . "<br>" . $connection->error;
    }

}
}
}

?>

          <!-- <img src="images/signup-bg.jpg" alt=""> -->

                <form action="create_admin.php" method="post" role="form" autocomplete="off">
                  <h2 class="form-title text-center">Create Admin</h2><hr>
                  <div class="form-group">
                    <label for="fname">Full Name*:</label>
                    <input type="text" name="fname" value="<?=(isset($fname))?$fname:'';?> "  id="fname"  class="form-control" placeholder="First name">
                  </div>

                  <div class="form-group">
                    <label for="uname">User Name*:</label>
                    <input type="text" name="uname" value="<?=(isset($username))?$username:'';?> "  class="form-control" placeholder="User name">
                  </div>
                  <div class="form-group">
                    <label for="email">Email*:</label>
                    <input type="email" name="email" value="<?=(isset($email))?$email:'';?> " class="form-control" placeholder="please  insert your email">
                  </div>
                  <div class="form-group">
                    <label for="psw">Passwword*:</label>
                    <input type="password" name="psw" value="<?=(isset($password))?$password:'';?> " class="form-control" placeholder="please insert password">
                  </div>
                  <div class="form-group">
                    <label for="rpsw">Re-peat Pasword*:</label>
                    <input type="password" name="rpsw" value="<?=(isset($confirm))?$confirm:'';?> "  class="form-control" placeholder="Reapeat Passwword">
                  </div>
                  <div class="form-group">
                    <input type="submit" name="signup" value="Create user" class="btn btn-success">
                  </div>
                  <p class="loginhere">
                    Have already an account ? <a href="login.php" class="loginhere-link">Login here</a>
                  </p>
                </form>
              </div>
          </div>
</section>
