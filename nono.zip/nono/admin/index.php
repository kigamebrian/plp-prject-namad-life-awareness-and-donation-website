<?php
include 'includes/header.php';
if(!is_logged_in()){
  header('Location:login.php');

}
if(isset($_SESSION["user_id"])) {
	if(!isLoginSessionExpired()) {
		header("Location:user_dashboard.php");
	} else {
		header("Location:logout.php?session_expired=1");
	}
}

?>
<style type="text/css">
span {
    color: #095506;
}

</style>
 <div id="wrapper">

        <!-- Navigation -->
       <?php include 'includes/navigation.php'; ?>


        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
				      	</div>


                        <h1 class="page-header text-center">
                            Welcome Nobility Of <span>Nature</span> Organization Admin Panel
                        </h1>
                    </div>
                </div>
                <!-- /.row -->
<div class="row">
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-file-text fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">


                        <div>Blogs & News<br>
                      <p style="font-size:50px;font-weight:700;"><?=GetNumberPost();?></p>
                        </div>

                    </div>
                </div>
            </div>
            <a href="posts.php?source=">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-green">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comments fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">

                      <div>Comments<br>
                        <p style="font-size:50px;font-weight:700;"><?=GetNumbercomments();?></p>
                      </div>
                    </div>
                </div>
            </div>
            <a href="comment.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-yellow">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-calendar fa-5x"></i>
                    </div>
                    <div class="col-xs-9 text-right">

                        <div>Events<br>
                          <p style="font-size:50px;font-weight:700;"><?=GetNumberEvents();?></p>
                        </div>
                    </div>
                </div>
            </div>
            <a href="events.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>
    <div class="col-lg-3 col-md-6">
        <div class="panel panel-red">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-xs-3">
                        <i class="fa fa-comment fa-5x" aria-hidden="true"></i>

                    </div>
                    <div class="col-xs-9 text-right">

                         <div>Messages/Enquries<br>
                           <p style="font-size:50px;font-weight:700;"><?=GetNumberMessages();?></p>
                         </div>
                    </div>
                </div>
            </div>
            <a href="Messages.php">
                <div class="panel-footer">
                    <span class="pull-left">View Details</span>
                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                    <div class="clearfix"></div>
                </div>
            </a>
        </div>
    </div>

</div>
<div class="row">
  <div class="col-md-12">
    <hr>
    <h4 class="text-center">Organization Documents</h4>
      <hr>
  </div>

  <div class="col-md-4">
    <div class="panel-heading">
      <p> <i> Fill This Form To Add new document</i></p>
    </div>
    <form class="" action="adddocs.php" method="post" enctype="multipart/form-data">
      <div class="form-group">
      <input type="text" class="form-control" name="doc_name" placeholder="Document Name" >
    </div>
    <div class="form-group">
      <input type="file" name="doc" class="form-control">
    </div>
      <input type="submit" class="btn btn-success" name="submit" value="Upload">

    </form>

  </div>
  <div class="col-md-6">
    <div class="panel-heading">
        <p><i>All Documents</i></p>
    </div>
    <table  class="table table-bordered table-striped table-condensed border-0">
      <thead class="bg-success white"><th>#</th><th>Document Name</th> <th>Action</th></thead>

        <?php show_documents(); ?>


    </table>

  </div>

</div>

                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <hr>
            <table  class="table table-bordered table-striped teble-condensed">
              <h4 class="text-center">Online Users<hr></h4>
              <thead><th class="text-center">#</th> <th class="text-center">Username</th><th class="text-center">Email</th><th class="text-center">status</th></thead>
            <tbody  id="user_grid">

          </tbody>
            </table>



          	</div>
          		<!-- /.container-fluid -->

          	</div>
          	<!-- /#page-wrapper -->


        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->
    <script>
    function updateUserStatus(){
      jQuery.ajax({
        url:'action.php',
        success:function(){

        }
      });
    }
    function getUserStatus(){
      jQuery.ajax({
        url:'get_user_status.php',
        success:function(result){
            jQuery('#user_grid').html(result);
        }
      });
    }
    setInterval(function(){
      updateUserStatus();

    },1000);
    setInterval(function(){
      getUserStatus();

    },1000);
    </script>


</body>

</html>
