<?php
include 'includes/header.php';
if(isset($_SESSION['login_user'])){
  header("Location:index.php");
//echo '<script type="text/javascript"> window.location = "https://www.kigzblog.com/admin"</script>';
 }
?>

<style type="text/css">
body {
    background-color: #f8f8f8;
}
span {
    color: #095506;
}
</style>

<body style="zoom: 1;">

    <div class="container">
      <div class="row">
                <div class="col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-default">
                                                <div class="panel-heading">



<?php
if(!isset($_GET["token"])){
  exit("<p class='bg-danger text-center'>Can't find page</p>");
}
$token =$_GET["token"];
$curDate = date("Y-m-d H:i:s");

$getEmailQuery = mysqli_query($connection,"SELECT  * FROM resetpass WHERE token='$token'");
$row=mysqli_fetch_assoc($getEmailQuery);
$expDate=$row['expDate'];
if ($expDate < $curDate){
  exit("The link is expired. You are trying to use the expired link which
as valid only 24 hours");
}
if(mysqli_num_rows($getEmailQuery)== 0){
  exit("Can't find page");
}
if(isset($_POST["submit"])){
  $password=$_POST['password'];
  $confirm=$_POST['rpsw'];
  $email= $row["email"];
  $uppercase = preg_match('@[A-Z]@', $password);
  $lowercase = preg_match('@[a-z]@', $password);
  $number    = preg_match('@[0-9]@', $password);
  $specialChars = preg_match('@[^\w]@', $password);

  $errors =array();
  if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($password) < 8) {
      $errors[]='Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.';
}
    if ($password != $confirm){
      $errors[]='Your password do not match';
    }
    if(!empty($errors)){
      echo display_errors($errors);

    }
else{
  $hashed=password_hash($password,PASSWORD_DEFAULT);
  $query =mysqli_query($connection,"UPDATE users SET pasword='$hashed' WHERE email='$email'");
  if($query){
    $query=mysqli_query($connection, "DELETE FROM  resetpass WHERE token='$token'");
    header("Location: login.php?");
    $_SESSION['success_flash']='password updated successfully';
  }
  else {
    // code...
    exit("something went wrong");
  }

}
}

?>
<p class="text-center">Reset password</p>
</div>

     <div class="panel-body">
          <form role="form" action="" method="post">
          <fieldset>
            <div class="form-group">
                <input class="form-control" placeholder="Password" name="password" id="password"  type="password" data-toggle="password">
            </div>
              <div class="form-group">
                  <input class="form-control" placeholder="confirm Password" name="rpsw" id="rpsw"  type="password" data-toggle="password">
              </div>

              <!-- Change this to a button or input when using this as a form -->
              <input type="submit" class="btn btn-lg btn-success btn-block" name="submit" value="submit email">
          </fieldset>
      </form>


     </div>

     </div>
   </div>
 </div>
</div>
<div align="center">
Develop By <a href="https://www.kigzblog.com" target="_blank">&lt;kigz&gt;</a></div>
<!-- jQuery Version 1.11.0 -->
<script src="js/jquery-1.11.0.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="js/plugins/metisMenu/metisMenu.min.js"></script>

<!-- Custom Theme JavaScript -->
<script src="js/sb-admin-2.js"></script>
<script type="text/javascript">
$("#password").password('toggle');
</script>

</body>
