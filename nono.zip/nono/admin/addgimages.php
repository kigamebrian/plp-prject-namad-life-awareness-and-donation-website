<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}
?>
<div id="wrapper">

    <!-- Navigation -->
   <?php include 'includes/navigation.php'; ?>


    <div id="page-wrapper">

        <div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

                <div class="col-lg-12">
                    <h1 class="page-header text-center">Add Gallery</h1>
                </div>

                <!-- /.col-lg-12 -->


<?php
if (isset($_POST['submit'])) {

$agid=$_REQUEST['id'];
$gid=$agid;
$sql = "select * from tbl_album where albumid='$agid'";
$rs_result = $connection->query($sql);
$row = mysqli_fetch_assoc($rs_result);
$aname=$row["name"];
$gname=$aname;
$gdate = date('Y-m-d H:i:s');
$status='process';
$rd=rand();
$errors =array();

if(isset($_FILES['upload1'])){

	foreach($_FILES['upload1']['tmp_name'] as $key => $tmp_name){
		$file_name = $key.$rd.$_FILES['upload1']['name'][$key];
		$file_size =$_FILES['upload1']['size'][$key];
		$file_tmp =$_FILES['upload1']['tmp_name'][$key];
		$file_type=$_FILES['upload1']['type'][$key];
    $allowedTypes = array('jpg','png','jpeg','gif');

        if($file_size > 2097152){
			$errors[]='File size must be less than 2 MB';
        }

        $desired_dir="gupload";
        if(empty($errors)==true){
            if(is_dir($desired_dir)==false){
                mkdir("$desired_dir", 'gupload');
            }
            if(is_dir("$desired_dir/".$file_name)==false){

$src = imagecreatefromjpeg($tmp_name);
list($width,$height)=getimagesize($tmp_name);
$newwidth=($width/$height)*150;
$newheight=150;
$tmp=imagecreatetruecolor($newwidth,$newheight);
imagecopyresampled($tmp,$src,0,0,0,0,$newwidth,$newheight,$width,$height);
$rd=rand();
$filename = "gcatch/".$file_name;
imagejpeg($tmp,$filename,100);
imagedestroy($src);
move_uploaded_file($file_tmp,"$desired_dir/".$file_name);
            }else{									// rename the file if another one exist
                $new_dir="$desired_dir/".$file_name.time();
                 rename($file_tmp,$new_dir) ;
            }
$query="INSERT INTO tbl_gallery(aid,gname,gimages,gdate,status) VALUES('$gid','$gname','$file_name','$gdate','$status')";
mysqli_query($connection, $query);

        }
		else
		{
		    print_r($errors);

        }
    }
	if(empty($errors)){

	echo " <div class='alert alert-success'>Your Photos Is Successfully Uploded. <a href='viewphotos.php'>View Photos</a> |<a href='addevent.php'> Add new Photos</a></div>";

	}

}

}

?>

                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Fill This Form To Add Gallery
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form action="#" method="post" enctype="multipart/form-data" name="upload">


                                        <div class="form-group">
                                            <label>Gallery Image</label>
                                            <input type="file" name="upload1[]" multiple  id="upload" />

                                            <p class="help-block">Example "Recomended Image Size in pixel 400 X 300"</p>
                                        </div>

                                        <button type="submit" class="btn btn-primary" name="submit">Submit</button>

                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery Version 1.11.0 -->
    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
