<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}
if(isset($_GET['delete'])){
  $delete_id =sanitize($_GET['delete']);
  $connection->query ("DELETE FROM contact_form_infor WHERE id ='$delete_id'");
  $_SESSION['success_flash'] ='message has been deleted successfully';
  header('Location:Messages.php');
}
$Query =$connection->query("SELECT * FROM contact_form_infor ORDER BY full_name");
?>
<div id="wrapper">

    <!-- Navigation -->
   <?php include 'includes/navigation.php'; ?>


    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
              <div class="col-lg-12">
                  <h1 class="page-header text-center">Mesages</h1>
              </div>
              <div class="col-lg-12">
                  <div class="panel panel-default">

                        <div class="panel-heading">
                          <i>All messages </i> 
                        </div>
                    <table class="table table-striped">
                      <thead class="thead-dark">
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Sender Name</th>
                          <th scope="col">Sender Email</th>
                          <th scope="col">Message</th>
                          <th>Delete</th>
                        </tr>
                      </thead>
                      <?php
                      $i=1;
                      while($message=mysqli_fetch_assoc($Query)){

                      ?>
                      <tr>
                        <th scope="row"><?=$i ?></th>
                        <td><?=$message['full_name'];?></td>
                          <td><?=$message['email'];?></td>
                        <td><?=$message['message'];?></td>
                        <td><a href="Messages.php?delete=<?=$message['id']; ?>" class="btn btn-default btn-xs"><span class="glyphicon glyphicon-remove-sign"></span></a></td>

                      </tr>
                      <?php
                      $i++;
                       }
                      ?>

                    </table>
                          <!-- /.row (nested) -->
                      </div>
                      <!-- /.panel-body -->
                  </div>
                </div>
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->


<!-- /#wrapper -->


</body>

</html>
