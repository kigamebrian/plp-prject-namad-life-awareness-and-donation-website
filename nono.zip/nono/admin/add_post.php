<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';
function add_post(){
  global $connection;
  if (isset($_POST['publish'])) {
    $post_title = sanitize($_POST['title']);
    $post_author = sanitize($_POST['author']);
    $post_category = sanitize($_POST['category']);
  // get the cat id
    $sql=mysqli_query($connection,"SELECT id FROM categories WHERE title='$post_category'");
    $row=mysqli_fetch_array($sql);
    $post_category_id=$row['id'];
    $post_content =$_POST['content'];
    $post_tags = sanitize($_POST['tags']);
    $post_status =sanitize( $_POST['status']);

    $date = date("l d F Y");
    $post_views = 0;
    $post_comment_count = 0;

    if (isset($_FILES['post_image'])) {
      $image = $_FILES['post_image']['name'];
      $ImageName= time() . '-' . $_FILES["post_image"]["name"];
      $target_dir= "imgs/";
      $target_file = $target_dir . basename($ImageName);
      $fileType = pathinfo($target_file,PATHINFO_EXTENSION);
      $allowTypes = array('jpg','png','jpeg','gif','pdf');
      if($_FILES['post_image']['size'] > 200000) {
        $msg = "Image size should not be greated than 200Kb";
        $msg_class = "alert-danger";
      }
      if(file_exists($target_file)) {
        $msg = "File already exists";
        $msg_class = "alert-danger";
      }
      if(!in_array($fileType, $allowTypes))
      {
        $error = "Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload";
         $msg = "alert-danger";
  }
      // Upload image only if no errors
      if (empty($error)) {
        if(move_uploaded_file($_FILES["post_image"]["tmp_name"], $target_file)) {

        $msg = "Image uploaded and saved ";
        $msg_class = "alert-success";
      } else {
        $msg = "There was an error in the database";
        $msg_class = "alert-danger";
      }
    }
  }

    $query = "INSERT INTO posts (title,author,post_content,post_image,post_date,post_tags,post_status)
    VALUES('$post_title','$post_author','$post_content','$target_file','$date','$post_tags','$post_status')";
    $result = mysqli_query($connection, $query);
    if (!$result) {
      die("Could not send data " . mysqli_error($connection));
      header("Location: posts.php?source=add_new");
    }else{
      header("Location: posts.php?source=");
      $_SESSION['success_flash']='posts  added  successfully';
    }
  }
}

add_post();
