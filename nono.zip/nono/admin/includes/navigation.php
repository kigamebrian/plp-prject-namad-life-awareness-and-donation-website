
 <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Admin</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                  <li><a href="../index.php">Visit Site</a></li>
                <li class="dropdwn">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Hello <?=$username ?>!<span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li><a href="profile.php"><i class="fa fa-fw fa-user"></i> Profile</a></li>
                    <li><a href="change_password.php"><i class="fa fa-key" aria-hidden="true"></i>Change Password</a></li>
                    <li><a href="logout.php"><i class="fa fa-sign-out"></i> Log Out</a></li>
                  </ul>
                </li>
            </ul>
             <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-send"></i> Blog&News  <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="posts.php?source=">View Blogs & News</a>
                            </li>
                            <li>
                                <a href="posts.php?source=add_new">Add New Blog</a>
                            </li>

                        </ul>
                    </li>
                       <li>
                        <a href="events.php"><i class="fa fa-fw fa-suitcase"></i> Events <i class="fa fa-fw fa-caret-down"></i></a>
                    </li>
                    <li>
                    <a href="#demo"  data-toggle="collapse"  data-target="#gallary"><i class="fa fa-file-photo-o fa-fw"></i> Gallary <i class="fa fa-fw fa-caret-down"></i></a>
                     <ul id="gallary" class="collapse">

                           <li>
                               <a href="addgallery.php">Add Gallery</a>
                             </li>
                           <li>
                              <a href="viewsgallery.php">View Gallery</a>
                          </li>
                          <li>
                              <a class="active" href="addalbum.php">Add Album</a>
                            </li>
                          <li>
                              <a href="viewallalbums.php">View Album</a>
                          </li>
                        </ul>
                    </li>
                    <li>
                    <a href="#demo"  data-toggle="collapse"  data-target="#team"><i class="fa fa-users" aria-hidden="true"></i> Team <i class="fa fa-fw fa-caret-down"></i></a>
                     <ul id="team" class="collapse">

                           <li>
                               <a href="viewteam.php">veiw Team</a>
                             </li>
                           <li>
                              <a href="ateam.php">Add Team Member</a>
                          </li>

                        </ul>
                    </li>
                      <li>
                        <a href="comment.php"><i class="fa fa-fw fa-comment"></i> Comments </a>
                    </li>
                       <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#users"><i class="fa fa-user" aria-hidden="true"></i> Users <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="users" class="collapse">
                            <li>

                                <a href="users.php">View All Users</a>
                            </li>
                            <li>
                                <a href="Add_users.php">Add New Users</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="profile.php"><i class="fa fa-fw fa-user"></i> Profile</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>
       <script src="bootstrap/js/jquery.js"></script>
       <script type="text/javascript">


       jQuery(document.body).on('click', function(ev){
    if(jQuery(ev.target).closest('.collapse').length) return; // Not return false

    // Hide navbar
});
   </script>
