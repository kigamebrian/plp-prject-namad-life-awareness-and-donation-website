<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';


function show_Event(){
  global $connection;
  $query = "SELECT * FROM events";
  $result = mysqli_query($connection, $query);

  while ($row = mysqli_fetch_assoc($result)) {
    $event_id=$row['id'];
    $event_title = $row['title'];
    $event_date = $row['event_date'];
    $stime=$row['start_time'];

    echo "<tr>";
    echo "<td>{$event_title}</td>";
    echo "<td>{$event_date}</td>";
    echo "<td>{$stime}</td>";
    echo "<td><a href='events.php?delete_event={$event_id}'>Delete</a></td>";
    echo "</tr>";
  }
}

function delete_event(){
  global $connection;
  if (isset($_GET['delete_event'])) {
    $event_id = $_GET['delete_event'];
    $query = "DELETE FROM events WHERE $event_id =id";
    $result = mysqli_query($connection, $query);
    if (!$result) {
      die("Could not delete data " . mysqli_error($connection));
    }
    else{
      header("Location: events.php?event_deleted");
    }
  }
}
delete_event();


function show_posts(){
  global $connection;
  $user=$_SESSION['login_user'];
  $sql =mysqli_query($connection,"SELECT * FROM users WHERE id='$user'");
  $res=mysqli_fetch_array($sql);
  $username=$res['username'];
  $permissions=$res['permissions'];
  if($permissions === 'Admin'){
    $query = "SELECT * FROM posts";
    }
    else{
      $query = "SELECT * FROM posts WHERE author='$username'";
    }
  $result = mysqli_query($connection, $query);

  while ($row = mysqli_fetch_assoc($result)) {
    $post_id = $row['id'];
    $post_title = substr($row['title'],0,20);
    $post_author = $row['author'];
    $post_content = substr($row['post_content'],0,50);
    $post_tags = substr($row['post_tags'],0,20);
    $post_status = $row['post_status'];
    $post_image = $row['post_image'];
    $date = $row['post_date'];


    echo "<tr>";
    echo "<td>{$post_id}</td>";
    echo "<td>{$post_title}</td>";
    echo "<td>{$post_author}</td>";
    echo "<td>{$post_status}</td>";
    echo "<td><img src='./{$post_image}' width='50px'></td>";
    echo "<td>{$post_content!}</td>";
    echo "<td>{$date}</td>";
    echo "<td>{$post_tags}</td>";
    echo "<td><a href='posts.php?approve_post=$post_id'class='btn btn-success'>change Status</a></td>";
    echo "<td><a href='posts.php?source=edit&edit_post=$post_id'class='btn btn-primary' >Edit</a></td>";
    echo "<td><a href='posts.php?delete_post=$post_id' class='btn btn-danger'>Delete</a></td>";
    echo "</tr>";

  }
}
// publish or publish
function modifyStatus($id){
  global $connection;
  $query = mysqli_query($connection,"SELECT  post_status FROM posts WHERE id=$id");
  if(mysqli_num_rows($query)>0){
    $result = mysqli_fetch_array($query);
    $status =$result['post_status'];

    if($status == Draft){
      $query =mysqli_query ($connection, " UPDATE posts SET post_status='Published' WHERE id =$id");
    }
    else{
      $query =mysqli_query ($connection, " UPDATE posts SET post_status='Draft' WHERE id =$id");
    }
    return true;
  }
  else{
    return false;
  }
}
//edit post=


function show_Members(){
  global $connection;
  $user=$_SESSION['login_user'];
  $query = "SELECT * FROM members";
  $result = mysqli_query($connection, $query);

  while ($row = mysqli_fetch_assoc($result)) {
    $member_id = $row['id'];
    $member_name = substr($row['name'],0,50);
    $member_position= $row['position'];
    $member_bio= substr($row['bio'],0,100);
    $member_photo= $row['member_picture'];

   echo'<div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 profile">
           <div class="img-box">
             <img src="'.$member_photo.'" class="img-responsive" alt="'.$member_name.'" style="height:30vh; width:100%;">
                 <ul class="text-center">

                     <a href="#" data-toggle="popover" title="'.$member_name.'" data-content="'.$member_bio.'"><i class="fa fa-caret-down"></i></a>
                     <a href="editmember.php?edit_member='.$member_id.'"><i class="fa fa-pencil" aria-hidden="true"></i></li></a>
                     <a href="viewteam.php?delete_member='.$member_id.'"><i class="fa fa-times"></i></i></li></a>


                 </ul>
                 </div>
                 <h1><b>'.$member_name.'</b></h1>
               <h2 ><i>'.$member_position.'</i></h2>
               <p>'.$member_bio.'.</p>
               <hr>
                     </div>';

  }
}
function show_documents(){
  global $connection;
  $sql ="SELECT * FROM documents";
  $res= mysqli_query($connection, $sql);
  $i=1;
  while ($row =mysqli_fetch_assoc($res)){
    $id =$row['id'];
    $name =$row['name'];
    $path =$row['path'];


echo '<tr>';
echo'<th class="border-0"scope="row">'.$i.'</th>';
echo'<td class="border-0">'.$name.'</td>';
echo'<td class="border-0"><a href="index.php?delete_doc='.$id.'">delete</a></td>';
echo'<tr>';


$i++;
 }

}
function delete_doc(){
  global $connection;
  if (isset($_GET['delete_doc'])) {
    $doc_id = $_GET['delete_doc'];
    $query = "DELETE FROM documents WHERE $doc_id =id";
    $result = mysqli_query($connection, $query);
    if (!$result) {
      die("Could not delete data " . mysqli_error($connection));
    }
    else{
      header("Location: index.php?document_deleted");
    }
  }
}
delete_doc();
?>
