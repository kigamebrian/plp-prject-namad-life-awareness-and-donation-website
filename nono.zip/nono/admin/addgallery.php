<?php include 'includes/header.php';
include 'includes/navigation.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}
?>
<div id="wrapper">

	<!-- Navigation -->


	<div id="page-wrapper">

		<div class="container-fluid">

			<!-- Page Heading -->
			<div class="row">

					<h1 class="page-header text-center">
						Welcome to the Administration Panel
					</h1>




                <div class="col-lg-12">
                    <h1 class="page-header">Add Gallery</h1>
                </div>

                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <?php

		if(isset($_POST['submit']))
{
$ename = $_POST['category'];
}
			?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Fill This Form To Add Gallery
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    <form action="glink.php" method="post" enctype="multipart/form-data" name="upload">

                                        <div class="form-group">
                                            <label>Select Event Name or Title</label>


                                                <select class="form-control" name="category">
                                                  <?php
                                                  $sql = "select * from tbl_album where status='process'";
                                                   $rs_result = $connection->query($sql);
                                                   while ($row = mysqli_fetch_array($rs_result)) {
                                                     echo "<option value=$row[albumid]>$row[name]</option>";
                                                                                             };
                                                   ?>

                                                </select>


                                        </div>

                                        <button type="submit" class="btn btn-primary" name="submit">Go Next</button>

                                    </form>
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                                </div>
                                <!-- /.col-lg-6 (nested) -->
                            </div>
                            <!-- /.row (nested) -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery Version 1.11.0 -->

  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
