<?php
$ab=$_POST['category'];

echo $ab;
header( "Location:addgimages.php?id=$ab" );
?>
