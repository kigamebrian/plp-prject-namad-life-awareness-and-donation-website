<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';
$id=$_SESSION['login_user'];
$time=date("Y-m-d H:i:s");
$res=$connection->query("UPDATE users SET last_login='$time' WHERE id ='$id'");


 ?>
