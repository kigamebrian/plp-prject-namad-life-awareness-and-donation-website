<style>
form {

  border: 2px solid #00FFCC;
  border-radius: 5px;
  box-shadow: 2px 2px 15px rgba(0,0,0,6);
  margin: 0% auto;
  padding: 100px;
  background-color: #fff;
}
</style>
<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}
$id =$_SESSION['login_user'];
  $pwd =((isset($_POST['conf_psw']))?sanitize($_POST['conf_psw']):'');
  $query =mysqli_query($connection,"SELECT * FROM users WHERE id=$id");
  $record =mysqli_fetch_array($query);
  $hashPwd=password_hash($pwd, PASSWORD_DEFAULT);
  $pwsFromdb =$record['pasword'];
  $errors= array();
?>
<div id="wrapper">

    <!-- Navigation -->
    <?php include 'includes/navigation.php'; ?>


    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">

                <br>
                <p class="alert alert-info col-md-6">To update your profile picture and password go to the <a href="settings.php"><b>settings</b></a> page</p>

                <div class="col-md-12">
                  <div class="col-md-6 form">
                    <h3 class="text-center">Update your profile </h3>
  <?php
                          if($_POST){
                          if(!password_verify($pwd,$record['pasword'])){
                              $errors[]='The  empty or incorecrrect!';
                            }
                            if(!empty($errors)){
                              echo display_errors($errors);
                            }else{

                              if (isset($_FILES['post_image'])) {
                                $dir = "users/profile_pics/";
                                $target_file = $dir.basename($_FILES['post_image']['name']);
                                if (move_uploaded_file($_FILES['post_image']['tmp_name'],$target_file)) {

                                $connection->query("UPDATE users SET profile_pic = '$target_file' WHERE id= '$id'");
                                $_SESSION['success_flash']='Profile Picture  updated successfully';
                                  header('Location: profile.php');



                            }

                          }


                      }

                   }

                ?>



                        <form action="settings.php" method="post" enctype="multipart/form-data">
                          <div class="form-group">
                              <label for="username">Upload Profile Picture</label>
                              <input type="file" name="post_image" class="form-control">
                          </div>

                            <div class="form-group">
                                <label for="username">Password</label>
                                <input type="password" name="conf_psw" class="form-control" >
                            </div>
                            <div class="form-group">

                                <input type="submit" name="" class=" btn btn-success" >
                            </div>
                        </form>
                        </div>




            <!-- /.row -->

        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
<script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
