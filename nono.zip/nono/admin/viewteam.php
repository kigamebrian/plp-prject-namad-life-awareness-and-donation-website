
<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}

if(isset($_GET['delete_member']) && $_GET['delete_member'] !== ''){
  $dlt =$_GET['delete_member'];
  if(delete('members','id',$dlt)){
    redirect('viewteam.php');
    $_SESSION['success_flash']='User deleted successfully';
  }
	die('FAILED');
}
?>
<style type="text/css">
  .image-box img{
    height:200px;
  }
</style>
<div id="wrapper">

    <!-- Navigation -->
   <?php include 'includes/navigation.php'; ?>


    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
                <div class="col-lg-12">
                      <h1 class="page-header text-center">
                        Welcome to the Administration Panel
                    </h1>

                </div>
                  </div>
                <div class="row pt-md">



                  <?php show_Members(); ?>
                  </div>


            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<!-- jQuery -->
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});
</script>
    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
