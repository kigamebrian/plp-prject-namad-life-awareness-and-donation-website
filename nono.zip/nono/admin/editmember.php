<?php include 'includes/header.php';
if(!is_logged_in()){
  login_error_redirect();
}
if(!has_permission('Admin')){
  permission_error_redirect('index.php');
}

if(isset($_GET['edit_member']) && $_GET['edit_member'] !== ""){
  $edit_id = $_GET['edit_member'];
  $query=mysqli_query($connection,"SELECT * FROM members WHERE id=$edit_id");
  if(mysqli_num_rows($query)>0){
    $data =mysqli_fetch_array($query);
    $id =$data['id'];
    $name=$data['name'];
    $position=$data['position'];
    $bio =$data['bio'];
    $image =$data['member_picture'];



      }else{
        die("Failed");
      }


    }else{
        die("Failed");
    }


?>
<div id="wrapper">

    <!-- Navigation -->
   <?php include 'includes/navigation.php'; ?>


    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
              <div class="col-lg-12">
                  <h1 class="page-header text-center">Edit Member's information</h1>
              </div>
              <div class="col-lg-12">
                  <div class="panel panel-default">
                      <div class="panel-heading">
                          Fill This Form To Edit Team Member's information
                      </div>
                      <div class="panel-body">
                          <div class="row">
                              <div class="col-lg-6 ">
                                <?php if (!empty($errors)): ?>
                                  <div  role="alert"><?php echo $errors; ?></div>
                                <?php endif; ?>
                                  <form action="editmemberprocess.php" method="post" enctype="multipart/form-data" name="upload">


                                      <div class="form-group">
                                          <label>Member Full Name</label>
                                          <input type="text" name="name" class="form-control" id="mname" value="<?=$name;?>" />

                                          <p class="help-block">Example "John Doe"</p>
                                      </div>
                                      <div class="form-group">
                                          <label>Member Positon</label>
                                          <input type="text" name="position" multiple  id="postion" class="form-control" value="<?=$position;?>" />

                                          <p class="help-block">Example "CEO/Founder example Organization  "</p>
                                      </div>
                                      <div class="form-group">
                                          <label>Member's Bio Infor</label>
                                          <textarea type="text" name="bio" class="form-control"  id="bio" value="<?=$name;?>"><?=$bio;?></textarea>

                                          <p class="help-block"></p>
                                      </div>
                                      <div class="form-group">
                                          <label>Member's Photo</label>
                                          <input type="text" name="image" value="<?=$image?>" style="display: none;">
                                          <input type="text" name="editId" value="<?=$edit_id?>" style="display: none;">
                                          <input type="file" name="photo" class="form-control"  id="photo"/>
                                          <img src="<?=$image;?>"style="height:200px;width:auto;" alt="25">

                                          <p class="help-block"></p>
                                      </div>

                                      <button type="submit" class="btn btn-primary" name="submit">Update</button>

                                  </form>
                              </div>
                              <!-- /.col-lg-6 (nested) -->
                              </div>
                              <!-- /.col-lg-6 (nested) -->
                          </div>
                          <!-- /.row (nested) -->
                      </div>
                      <!-- /.panel-body -->
                  </div>
                </div>
            </div>
            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->


<!-- /#wrapper -->


</body>

</html>
