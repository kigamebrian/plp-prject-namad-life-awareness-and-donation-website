<?php

require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';
$uid=$_SESSION['login_user'];
$gap=10;
$time=date ("Y-m-d H:i:s", mktime (date("H"),date("i"),date("s")-$gap,date("m"),date("d"),date("Y")));
$sql =mysqli_query($connection,"SELECT * FROM users WHERE id='$uid'");
$res=mysqli_fetch_array($sql);
$permissions=$res['permissions'];
if($permissions === 'Admin'){
$query ="SELECT * FROM users WHERE last_login>'$time' ORDER BY full_name";
  }
  else{
    $query="SELECT * FROM users WHERE last_login>'$time' && id='$uid'";
  }
    $userQuery = mysqli_query($connection, $query);

$i=1;
$html='';
while($user =mysqli_fetch_assoc($userQuery)){
  $status= 'Offline';
  $class="bg-danger";
  $style="color:#CCCCCC";
  if($user['last_login']>$time){
    $status='Online';
    $class=" text-center";
    $color="color:#00FF33";

  }


$html.='


<tr>
  <th scope="row"class="text-center">'.$i.'</th>
    <td class="text-center">'.$user['username'].'</td>
  <td class="text-center">'.$user['email'].'</td>
  <td class="'.$class.'" style="'.$color.';">'.$status.'</td>

</tr>';
$i++;
}
echo $html;
?>
