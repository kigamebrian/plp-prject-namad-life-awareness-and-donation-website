<?php include 'includes/header.php';?>
<?php include 'includes/navigation.php'; ?>
<?php
if(!is_logged_in()){
  login_error_redirect();
}
$user=$_SESSION['login_user'];
$query =mysqli_query($connection,"SELECT * FROM users WHERE id='$user'");
$data=mysqli_fetch_array($query);
//update user infor
if(isset($_POST['update'])){
  $usr=sanitize($_POST['username']);
  $em=sanitize($_POST['email']);
  if(!empty($usr) &&($em)){
    $query =mysqli_query($connection, "UPDATE users SET username='$usr', email='$em' WHERE id='$user' ");
    if($query){
      header("Location:profile.php?message=updated");
    }
  }
}

 ?>

<div id="wrapper">

    <!-- Navigation -->



    <div id="page-wrapper">

        <div class="container-fluid">

            <!-- Page Heading -->
            <div class="row">
                <h3>Welcome to your profile page <?=$data['username'];?></h3>
                <br>
                <p class="alert alert-info col-md-6">To update your profile picture and password go to the <a href="settings.php"><b>settings</b></a> page</p>
                <div class="col-md-12">
                    <img src="<?php echo $data['profile_pic'];?>" alt="" style="width: 150px; height: 150px; border-radius: 100%;">
                    <form action="" method="post">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="username">Username</label>
                                <input type="text" name="username" class="form-control" value="<?=$data['username'];?>">
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" name="email" class="form-control"value="<?=$data['email'];?>">
                            </div>
                            <div class="form-group">
                                <label for="role">Role</label>
                                <input type="text" name="role" class="form-control" disabled value="<?=$data['permissions'];?>">
                            </div>
                            <div class="form-group">
                                <input type="submit" name="update" class="btn btn-success" value="Update your profile">
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- /.row -->

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->

<script>
    $(document).ready(function() {
        $("#form").submit(function(e) {
            let name = document.querySelector("#username").value,
                email = document.querySelector("#email").value,
                pwd = document.querySelector("#password").value,
                role = document.querySelector("#role").value,
                submit = document.querySelector("#submit").value;
            $("#msg").load('validator/validate.php', {
                username: name,
                email: email,
                password: pwd,
                role: role,
                submit: submit
            });
            e.preventDefault();
        });
    });
</script>


    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-transition.js"></script>
    <script type="text/javascript" src="http://twitter.github.io/bootstrap/assets/js/bootstrap-collapse.js"></script>

</body>

</html>
