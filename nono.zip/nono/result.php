<?php require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';
    $name = mysqli_real_escape_string($connection, $_POST['name']);
    $email = mysqli_real_escape_string($connection, $_POST['email']);
    $content = mysqli_real_escape_string($connection, $_POST['content']);
    $post_id = mysqli_real_escape_string($connection, $_POST['post_id']);
    $post_author=mysqli_real_escape_string($connection,$_POST['post_author']);
    $comment_date=date('Y-m-d H:i:s');
    $status= "Unapproved";


$q= $connection->prepare("INSERT INTO comment(name, email, body,comment_date,post_id,post_author,status) VALUES( ?, ?, ?,?,?,?,?)");
$q->bind_param("ssssiss",$name,$email,$content,$comment_date,$post_id,$post_author,$status);
$q->execute();


?>
