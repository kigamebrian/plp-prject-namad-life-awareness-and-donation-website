<?php
session_start();
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "nono";

$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
date_default_timezone_set('Africa/Nairobi');

if (!$connection) {
  die("Could'nt connect to the database " . mysqli_error($connection));
}

require_once $_SERVER['DOCUMENT_ROOT'].'/nono/config.php';
require_once BASEURL.'helpers/helpers.php';

if(isset($_SESSION['login_user'])){
  $user_id =$_SESSION['login_user'];
  $query =$connection->query ("SELECT * FROM users WHERE id ='$user_id'");
  $user_data =mysqli_fetch_array($query);
  $username=$user_data['username'];
  $profile=$user_data['profile_pic'];
  $permissions=$user_data['permissions'];
}

if(isset($_SESSION['success_flash'])){
  echo'<div class="bg-success"><p class="text-center">'.$_SESSION['success_flash'].'</p></div>';
  unset($_SESSION['success_flash']);
}

if(isset($_SESSION['error_flash'])){
  echo'<div class="bg-danger"><p class="text-danger text-center">'.$_SESSION['error_flash'].'</p></div>';
  unset($_SESSION['error_flash']);
}
