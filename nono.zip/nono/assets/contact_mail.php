

<?php
$statusMsg = '';
$msgClass = '';
$toEmail = "briankigame7@gmail.com";
$emailSubject = 'Contact Request Submitted by '.$_POST["name"];
$htmlContent = '<table width="400" border="1">
                <tr bgcolor="#CCCCCC">
                <h2 style="color:ffffff;">Contact Request Submitted</h2>
                <p><h4>Name</h4>'.$_POST["name"].'</p>
                <h4>Email</h4><p>'.$_POST["email"].'</p>
                <h4>Phone</h4><p>'.$_POST["phone"].'</p></tr>

               <tr><td> <h4>Subject</h4><p>'.$_POST["subject"].'</p>
               <h4>Message</h4><p>'.$_POST["message"].'</p></td></tr>
               </table>';

           // Set content-type header for sending HTML email
           $headers = "MIME-Version: 1.0" . "\r\n";
           $headers .= "Content-type: text/html; charset=iso-8859-1rn" . "\r\n";
           $headers .= 'From:'.$_POST["name"]. '<'. $_POST["email"].'>'. "\r\n";

           // Send email
           if(mail($toEmail,$emailSubject,$htmlContent,$headers)){
             echo"<p class='success'>Thank you for contacting us. We will be in touch with you very soon..</p>";
           } else {
             echo"<p class='error'>Problem in Sending Mail.</p>";
          }



?>
