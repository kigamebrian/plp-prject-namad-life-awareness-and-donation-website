<?php
require_once $_SERVER['DOCUMENT_ROOT']. '/nono/core/init.php';
if((isset($_POST['name'])&& $_POST['name'] !='') && (isset($_POST['email'])&& $_POST['email'] !=''))
{
  require_once("contact_mail.php");
  $yourName = $connection->real_escape_string($_POST['name']);
  $yourEmail = $connection->real_escape_string($_POST['email']);
  $subject = $connection->real_escape_string($_POST['subject']);
  $phone=$connection->real_escape_string($_POST['phone']);
  $message= $connection->real_escape_string($_POST['message']);

  $sql="INSERT INTO contact_form_infor(full_name,email,subject,phone_no,message) VALUES ('".$yourName."','".$yourEmail."', '".$subject."','".$phone."' ,'".$message."')";
  if(!$result = $connection->query($sql)){
  die('There was an error running the query [' . $connection->error . ']');
  }
  else
  {
  echo "Thank you! We will contact you soon";
  }
  }
  else
  {
  echo "Please fill Name and Email";
  }
  ?>
