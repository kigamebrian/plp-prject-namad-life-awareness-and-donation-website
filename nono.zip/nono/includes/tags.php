<?php
$sql ="SELECT *FROM posts ORDER BY id ";
$result =  $connection->query($sql);
 ?>
            <div class="tagcloud">
              <?php while($row =mysqli_fetch_assoc($result)){
              $tags=$row['post_tags'];
            echo " <a href=''>$tags</a>";
          }
              ?>

          </div>


    
