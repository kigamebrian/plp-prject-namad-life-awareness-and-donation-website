<!-- This demo uses float grid but you can use flex grid too -->
<style type="text/css">

</style>
<div class="top-bar" id="example-menu">
  <div class="top-bar-left">
  </div>
  <div class="top-bar-right">
    <ul class="menu col-md-6">
      <li><input class="form-control" id="myInput" type="text" placeholder="Search.."></li>

    </ul>
  </div>
</div>
