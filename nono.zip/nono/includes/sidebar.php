

  <div class="widget widget-text">
    <div class="widget-title">
      Recent Articles/News
    </div>

      <?php
      $query = "SELECT * FROM posts WHERE post_status ='Published' ORDER BY id DESC LIMIT 5";
      $result =  $connection->query($query);

      while ($row = mysqli_fetch_assoc($result)) {

        // code...
        $post_id = $row['id'];
        $post_title = $row['title'];
        $post_author = $row['author'];
        $post_content = $row['post_content'];
        $post_tags = $row['post_tags'];
        $post_status = $row['post_status'];
        $post_image = $row['post_image'];
        $date = $row['post_date'];


        ?>

            <a href="blog-single.php?post=<?=$post_id;?>">
              <div class="text">
                <h4><?=substr(($post_title),0,20);?></h4>

                <div class="post-meta">
                  <span class="mr-2"><?=$date;?></span>
                </div>
              </div>
            </a>
            <hr>


      <?php
      }
      ?>

  </div>
