
  <footer class="footer">
  <div class="footer-left col-md-4 col-sm-6">
    <p class="about">
      <span> Nobility Of Nature Organization</span> Ut congue augue non tellus bibendum, in varius tellus condimentum. In scelerisque nibh tortor, sed rhoncus odio condimentum in. Sed sed est ut sapien ultrices eleifend. Integer tellus est, vehicula eu lectus tincidunt,
      ultricies feugiat leo. Suspendisse tellus elit, pharetra in hendrerit ut, aliquam quis augue. Nam ut nibh mollis, tristique ante sed, viverra massa.
    </p>
    <div class="icons">
      <a href="#"><i class="fa fa-facebook"></i></a>
      <a href="#"><i class="fa fa-twitter"></i></a>
      <a href="#"><i class="fa fa-linkedin"></i></a>
      <a href="#"><i class="fa fa-google-plus"></i></a>
      <a href="#"><i class="fa fa-instagram"></i></a>
    </div>
  </div>
  <div class="footer-center col-md-4 col-sm-6">
    <div>
      <i class="fa fa-map-marker"></i>
      <p><span>upperhill</span> Nairobi,Kenya</p>
    </div>
    <div>
      <i class="fa fa-phone"></i>
      <p> (+254) 768989916</p>
    </div>
    <div>
      <i class="fa fa-envelope"></i>
      <p><a href="#">Nobilityke@gmail.com</a></p>
    </div>
  </div>
  <div class="footer-right col-md-4 col-sm-6">
    <h2> <img src="imgs/brand.png" style="height: 100px; width: auto" ></h2>
    <p class="menu">
      <a href="index.php"> Home</a> |
      <a href="Aboutus.php"> About</a> |
      <a href="#"> About Us</a> |
      <a href="contact.php"> Contact Us</a> |
      <a href="blog.php"> Blog</a> |

    </p>
</div>
  <div class="fcopy">
			<div class="contain">
				<div class="row">
					<div class="col-sm-12 col-md-12">
            <p class="name"  Copyright &copy; <script data-cfasync="false" src="https://www.toolsvoordelig.nl/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All Rights Reserved |Nobility Of Nature organization</p>
          </div>
					</div>
				</div>
			</div>

</footer>
