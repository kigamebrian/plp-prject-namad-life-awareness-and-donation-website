<?php

$sql ="SELECT * FROM documents";
$res=mysqli_query($connection,$sql);
 ?>
<style type="text/css">
.bg-success {
background-color: #28d094!important;
}
</style>

<div class="col-md-12">


<table  class="table table-bordered table-striped table-condensed border-0">
  <thead class="bg-success white"><th>#</th><th>Document Name</th> <th>Action</th></thead>
  <?php
  $i=1;
  while ($row =mysqli_fetch_assoc($res)){
    $id =$row['id'];
    $name =$row['name'];
    $path =$row['path'];

    ?>
  <tr>
    <th class="border-0"scope="row"><?=$i;?></th>
      <td class="border-0"><?=$name;?></td>
      <td class="border-0"><a href="download.php?down=admin/<?=$path;?>">download</a></td>



  </tr>

<?php
$i++;
 }
?>
</table>

</div>
