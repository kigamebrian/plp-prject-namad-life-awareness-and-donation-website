<style type="text/css">
.change{
  font-size: 1rem;
  font-weight: bold;
  letter-spacing: 0.1rem;
  text-align: center;
  overflow: hidden;
  padding: 0.5rem;
  color: #fff;
}
.typed-text{
  font-weight: normal;
  color:#fdbb00;
}
.cursor{
  display:inline-block;
  width: 1px;
  background-color: #fff;
  margin-left: 0.1rem;
  animation: blink 1s infinite;
}


@keyframes blink {
  0%{background-color: #fff;}
  49%{background-color: #fff;}
  50%{background-color:transparent;}
  99%{background-color: transparent;}
  100%{background-color: #fff;}
}

</style>
<div class="container">
  <div class="outer">
    <div class="details">
      <h1>NONO</h1>

      <h5>Nobility Of Nature Organization </h5>
      <p class="change" >Love is <span class="typed-text"></span><span class="cursor">&nbsp;</span></p>
      <p class="primary_btn mr-20">
      <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
      <input type="hidden" name="cmd" value="_s-xclick" />
      <input type="hidden" name="hosted_button_id" value="RL5APVZGZGGZU" />
      <input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Donate with PayPal button" />
    <!--  <img alt="" border="0" src="https://www.paypal.com/en_KE/i/scr/pixel.gif" width="1" height="1" />-->
      </form>

      </p>

    </div>

  </div>

</div>
