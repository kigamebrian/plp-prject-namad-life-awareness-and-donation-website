<header class="header">
      <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top" id="mainNav">
      <div class="container-fluid">
        <a class="navbar-brand js-scroll-trigger" href="index.php">
          <h2></h2>
         <img src="imgs/brand.png" style="height: 70px; width: auto" >
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>
             <li class="nav-item dropdown  main-menu">
                <a class="nav-link dropdown-toggle" href="Aboutus.php" >About</a>
                <div class="dropdown-menu main-menubox" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="Aboutus.php">About Us</a>
                  <a class="dropdown-item" href="ourteam.php">Our Team</a>
                  <a class="dropdown-item" href="downloads.php">Downloads</a>
                </div>
              </li>
               <li class="nav-item">
                  <a class="nav-link" href="events.php" aria-haspopup="true" aria-expanded="false">
                   Events
                  </a>

                </li>
            <li class="nav-item">
              <a class="nav-link" href="blog.php">Blog & News</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="gallery.php">Gallery</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contact.php">Contact US</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    </header>
    <br>
