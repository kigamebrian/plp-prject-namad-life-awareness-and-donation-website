<?php
$query = "SELECT * FROM events  ORDER BY id DESC";
$result =  $connection->query($query);

while ($row = mysqli_fetch_assoc($result)) {

  // code...
	$event_id = $row['id'];
  $event_title = $row['title'];
  $event_date =  date('F-d-Y ', strtotime($row['event_date']));
  $event_date = explode('-', $event_date);
	$month = $event_date[0];
  $day   = $event_date[1];
  $year  = $event_date[2];

  $stime = $row['start_time'];
  $etime = $row['end_time'];
  $location = $row['venue_location'];
	$discription=$row['event_description'];
	$image =$row['event_poster'];
?>

	<div class="col-sm-4 col-md-4">
					<div class="box-fundraising">
							<div class="media">
								<div class="meta-date">
					<div class="date"><?=$day;?></div>
					<div class="month"><?=$month;?></div>
				</div>
								<img src="admin/<?=$image;?>" alt=""class="responsive">
							</div>
							<div class="body-content">
								<p class="title"><a href="event-single.php?<?=$event_title;?>&event=<?=$event_id;?>"><?=$event_title;?></a></p>
								<div class="meta">
					<span class="date"><i class="fa fa-clock-o"></i> <?=$stime;?> -<?=$etime;?></span>
					<span class="location"><i class="fa fa-map-marker"></i>&nbsp; <?=$location;?></span>
				</div>
								<div class="text"><?=substr(($discription),0,100);?></div>
								<div class="spacer-30"></div>
								<a href="event-single.php?<?=$event_title;?>&event=<?=$event_id;?>" class="btn btn-primary">READ MORE</a>
							</div>
					</div>
			</div>

<?php

}
	?>
