<?php require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';?>
<?php require_once "classes/comment.php";?>
<?php $comment_obj= new Comment($connection);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Nobility Of Nature Organiation</title>
    <meta name="viewport" content="width=device-width, initial-scale=1,user-scalable=no">
    <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href=" https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet"href="css/main.css">
    <link rel="stylesheet" href="css/animate.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
      <script src="js/smoothscroll.min.js"></script>

    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/jquery.jssocials/1.4.0/jssocials.css" />
    <link type="text/css" rel="stylesheet" href="https://cdn.jsdelivr.net/jquery.jssocials/1.4.0/jssocials-theme-flat.css" />
    <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />

<link rel="stylesheet" href="stylesheets/navigation.css">
<link rel="stylesheet" type="text/css" href="stylesheets/style1.css" />
<link rel="stylesheet" type="text/css" href="stylesheets/style_common.css" />
<link href="litebox-master/assets/css/litebox.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="pe-icon-7-stroke/css/pe-icon-7-stroke.css">

	<!-- Optional - Adds useful class to manipulate icon font display -->
<link rel="stylesheet" href="pe-icon-7-stroke/css/helper.css">

<link rel="stylesheet" href="css/sass-compiled.css" />
  <!-- Custom Theme files -->

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
  <!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,700italic,400,300,600,800,700' rel='stylesheet' type='text/css'>

<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Mobile Specific Metas
================================================== -->








  <link href="litebox-master/assets/css/litebox.css" rel="stylesheet" type="text/css" media="all" />


<!-- The Menu -->
<link href="stylesheets/styles.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="pe-icon-7-stroke/css/pe-icon-7-stroke.css">

<!-- Optional - Adds useful class to manipulate icon font display -->
<link rel="stylesheet" href="pe-icon-7-stroke/css/helper.css">


</head>
<body>
