<?php include 'includes/header.php' ?>
<div class="container-wrapper">

<?php include 'includes/navigation.php' ?>

<br>
<br>
<br>
<br>
<!--banner area-->
<div class="section banner-page" data-background="imgs/bunner-single.jpg" style="background-image: url(&quot;imgs/bunner.jpg&quot;);">
		<div class="content-wrap pos-relative">
			<div class="d-flex justify-content-center bd-highlight mb-3">
				<div class="title-page">Donate</div>
			</div>
			<div class="d-flex justify-content-center bd-highlight mb-3">
			    <nav aria-label="breadcrumb">
				  <ol class="breadcrumb ">
				    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
				    <li class="breadcrumb-item active" aria-current="page">Donate</li>
				  </ol>
				</nav>
		  	</div>
		</div>
	</div>
<div class="donate">
  <form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top">
<input type="hidden" name="cmd" value="_s-xclick" />
<input type="hidden" name="hosted_button_id" value="RL5APVZGZGGZU" />
<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Donate with PayPal button" />
<img alt="" border="0" src="https://www.paypal.com/en_KE/i/scr/pixel.gif" width="1" height="1" />
</form>
</div>
</div>
