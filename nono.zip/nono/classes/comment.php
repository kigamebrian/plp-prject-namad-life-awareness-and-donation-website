<!--brian kigame-->
<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/nono/core/init.php';
 class Comment{
   private $con;

   public function __construct($con){
     $this->con= $con;
   }

   public function addComments($id,$name,$email,$body){
     if(!empty($body)){
       $query =mysqli_query($this->con,"INSERT INTO comments VALUES('','$name','$email','$body','Unapproved','$id');");
       if(!$query){
         die("Failed".mysqli_error($this->con));
       }
     }else {

      return false;
     }
   }
   public function getAprovedComments($id){
     $query= mysqli_query($this->con, "SELECT * FROM comment WHERE post_id=$id AND status='approved' ");
     $str ="";
     while ($row=mysqli_fetch_assoc($query)){
       $id =$row['id'];
       $post_id=$row['post_id'];
       $name=$row['name'];
       $body=$row['body'];
       $date=$row['comment_date'];
?>
              <div class="media-body ">
                <h5 class="media-heading mt-0 mb-1"><?=$name;?></h5><small><?=$date ;?></small></h5>
                <blockquote>
                <p><?=$body;?></p>
                </blockquote>
              </div>
              <hr>



  <?php   }

   }
   public function  getComments()
   {  global $permissions;
     $query=mysqli_query($this->con,"SELECT * FROM  comment ORDER BY id DESC ");
     $str ="";
     while($row = mysqli_fetch_array($query)){
       $id = $row['id'];
       $name =$row['name'];
       $email=$row['email'];
       $body=substr($row['body'],0,30);
       $post_id=$row['post_id'];
       $status=$row['status'];
       $date=$row['comment_date'];

       if($permissions !== 'Admin'){

       $str .= "<tr>
                <td>$id</td>
                <td>$name</td>
                <td>$email</td>
                <td>$body</td>
                <td>$status</td>
                <td>$post_id</td>
                <td>$date</td>

                </tr>";
              }
            else{
              $str .= "<tr>
                       <td>$id</td>
                       <td>$name</td>
                       <td>$email</td>
                       <td>$body</td>
                       <td>$status</td>
                       <td>$post_id</td>
                       <td>$date</td>
                       <td><a href='comment.php?app=$id' class='btn btn-primary'>Change Status</a></td>
                       <td><a href='comment.php?del_com=$id' class='btn btn-danger'>Delete</a></td>

                       </tr>";

            }
     }
     echo $str;
   }
 }
