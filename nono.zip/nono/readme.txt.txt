the admin password is 123@Kigame
import the sql file attached to phpmyadmin database
and 
copy the nono folder to htdocs in xamp
the go to http://localhost/nono/ for fron end 

and http://localhost/nono/admin to access admin panel
plp-prject-namad-life-awareness-and-donation-website
a website to create awareness for nomadic people contain donation module galllary contact form blog area event page admin area the admin can - control post news and blogs review comments beforenthry can appear on the fron end add memebers delete memberes add album and images in gallary it has a register system and password reset system (might not work since uses my personal email i have removed

the website helps create awaresness on what the nomadic people are going through and can be used to also raise cash fr charity

becouse of the size of the images i have deleted them but once you set up you can add the again