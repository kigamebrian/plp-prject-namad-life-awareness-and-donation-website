-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2022 at 02:11 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nono`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `comment_date` varchar(255) NOT NULL,
  `post_id` int(11) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `name`, `email`, `body`, `comment_date`, `post_id`, `post_author`, `status`) VALUES
(1, 'brian', 'briankigame7@gmail.com', 'budada mambo', '2020-08-10 19:48:58', 1, 'brian', 'Approved'),
(2, 'kigame', 'b.kigame@yahoo.com', 'hallo bro', '2020-08-26 13:28:26', 1, 'brian', 'Approved'),
(3, 'kigame', 'briankigame7@gmail.com', 'amzing', '2020-08-26 13:34:00', 1, 'brian', 'Approved'),
(4, 'kigame', 'b.kigame@yahoo.com', 'hallo how is you', '2020-08-26 13:39:32', 1, 'brian', 'Approved'),
(5, 'lunganyi', 'briankigame7@gmail.com', 'kkk', '2022-09-28 13:37:15', 6, 'brian', 'Approved'),
(6, 'lunganyi', 'eustusk@gmail.com', 'lll', '2022-09-28 13:38:16', 6, 'brian', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `contact_form_infor`
--

CREATE TABLE `contact_form_infor` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `phone_no` varchar(255) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_form_infor`
--

INSERT INTO `contact_form_infor` (`id`, `full_name`, `email`, `subject`, `phone_no`, `message`) VALUES
(4, 'brian  kigame', 'briankigame7@gmail.com', 'hallo ', '0719106727', 'Ut congue augue non tellus bibendum, in varius tellus condimentum. In scelerisque nibh tortor, sed rhoncus odio condimentum in. Sed sed est ut sapien ultrices eleifend. Integer tellus est, vehicula eu lectus tincidunt, ultricies feugiat leo. Suspendisse tellus elit, pharetra in hendrerit ut, aliquam quis augue. Nam ut nibh mollis, tristique ante sed, viverra massa.\r\n\r\n'),
(8, 'brian  kigame', 'briankigame7@gmail.com', 'hallo ', '0719106727', 'Ut congue augue non tellus bibendum, in varius tellus condimentum. In scelerisque nibh tortor, sed rhoncus odio condimentum in. Sed sed est ut sapien ultrices eleifend. Integer tellus est, vehicula eu lectus tincidunt, ultricies feugiat leo. Suspendisse tellus elit, pharetra in hendrerit ut, aliquam quis augue. Nam ut nibh mollis, tristique ante sed, viverra massa.'),
(9, 'brian  kigame', 'briankigame7@gmail.com', 'hallo ', '0719106727', 'Ut congue augue non tellus bibendum, in varius tellus condimentum. In scelerisque nibh tortor, sed rhoncus odio condimentum in. Sed sed est ut sapien ultrices eleifend. Integer tellus est, vehicula eu lectus tincidunt, ultricies feugiat leo. Suspendisse tellus elit, pharetra in hendrerit ut, aliquam quis augue. Nam ut nibh mollis, tristique ante sed, viverra massa.'),
(10, 'brian  kigame', 'oliverblessig@gmail.com', 'hallo ', '0719106727', 'Ut congue augue non tellus bibendum, in varius tellus condimentum. In scelerisque nibh tortor, sed rhoncus odio condimentum in. Sed sed est ut sapien ultrices eleifend. Integer tellus est, vehicula eu lectus tincidunt, ultricies feugiat leo. Suspendisse tellus elit, pharetra in hendrerit ut, aliquam quis augue. Nam ut nibh mollis, tristique ante sed, viverra massa.'),
(11, 'brian  kigame', 'oliverblessig@gmail.com', 'hallo ', '0719106727', 'hallo how are you hope you are doing well\r\n\r\n'),
(12, 'kigame', 'kigamebrian5@gmail.com', 'greetings', '0719106727', 'Definition and Usage\r\nThe colspan attribute defines the number of columns a cell should spa'),
(13, 'kigame', 'kigamebrian5@gmail.com', 'test', '0719106727', 'Definition and Usage\r\nThe colspan attribute defines the number of columns a cell should spa'),
(15, 'kigame', 'kigamebrian5@gmail.com', 'greetings', '0719106727', 'Ut congue augue non tellus bibendum, in varius tellus condimentum. In scelerisque nibh tortor, sed rhoncus odio condimentum in. Sed sed est ut sapien ultrices eleifend. Integer tellus est, vehicula eu lectus tincidunt, ultricies feugiat leo. Suspendisse tellus elit, pharetra in hendrerit ut, aliquam quis augue. Nam ut nibh mollis, tristique ante sed, viverra massa');

-- --------------------------------------------------------

--
-- Table structure for table `documents`
--

CREATE TABLE `documents` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `path` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `event_description` text NOT NULL,
  `event_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `event_poster` text NOT NULL,
  `venue_location` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `event_description`, `event_date`, `start_time`, `end_time`, `event_poster`, `venue_location`) VALUES
(44, ' The chilling tale of DRACULA comes to life at village halls across Norfolk!', 'The 19th Century, gothic fable of DRACULA, will be told to those who dare\r\n\r\nto listen in village halls across Norfolk throughout October, with support from the arts and community development charity Creative Arts East.\r\n\r\nThis classic tale is told with all the grace of a 1930&rsquo;s Hollywood horror, by a cast of five slightly deranged and definitely contagious actors from the established theatre company The Keeper&rsquo;s Daughter. This rapid retelling of strangers binding together in order to defeat a greater evil thunders along at lightning pace, with The Keeper&rsquo;s Daughter presenting a faithful and unique adaptation of Bram Stoker&rsquo;s\r\n\r\ntimeless story.\r\n\r\nThis inventive theatre company uses theatre and storytelling to stimulate imagination as well as using elements of Lecoq physical theatre: clown, ensemble and chorus work. Their style is big, fast and imaginative', '2020-09-03', '07:06:00', '13:06:00', 'eventimgs/1599052003-Dracula.jpg', 'narok,kenya'),
(45, 'October 2013 Creative Arts East LIVE events in Norfolk and Suffolk', 'The 19th Century, gothic fable of DRACULA, will be told to those who dare\r\n\r\nto listen in village halls across Norfolk throughout October, with support from the arts and community development charity Creative Arts East.\r\n\r\nThis classic tale is told with all the grace of a 1930&rsquo;s Hollywood horror, by a cast of five slightly deranged and definitely contagious actors from the established theatre company The Keeper&rsquo;s Daughter. This rapid retelling of strangers binding together in order to defeat a greater evil thunders along at lightning pace, with The Keeper&rsquo;s Daughter presenting a faithful and unique adaptation of Bram Stoker&rsquo;s\r\n\r\ntimeless story.\r\n\r\nThis inventive theatre company uses theatre and storytelling to stimulate imagination as well as using elements of Lecoq physical theatre: clown, ensemble and chorus work. Their style is big, fast and imaginative', '2020-09-03', '17:08:00', '18:08:00', 'eventimgs/1599052102-go322222.jpg', 'narok,kenya'),
(46, 'October 2013 Creative Arts East LIVE events in Norfolk and Suffolk', 'The 19th Century, gothic fable of DRACULA, will be told to those who dare\r\n\r\nto listen in village halls across Norfolk throughout October, with support from the arts and community development charity Creative Arts East.\r\n\r\nThis classic tale is told with all the grace of a 1930&rsquo;s Hollywood horror, by a cast of five slightly deranged and definitely contagious actors from the established theatre company The Keeper&rsquo;s Daughter. This rapid retelling of strangers binding together in order to defeat a greater evil thunders along at lightning pace, with The Keeper&rsquo;s Daughter presenting a faithful and unique adaptation of Bram Stoker&rsquo;s\r\n\r\ntimeless story.\r\n\r\nThis inventive theatre company uses theatre and storytelling to stimulate imagination as well as using elements of Lecoq physical theatre: clown, ensemble and chorus work. Their style is big, fast and imaginative', '2020-09-03', '09:09:00', '14:09:00', 'eventimgs/1599052168-event.jpeg', 'narok,kenya');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(300) NOT NULL,
  `bio` text NOT NULL,
  `member_picture` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `position`, `bio`, `member_picture`) VALUES
(6, 'peter waiguru kamuyu', 'CEO', 'awesome guy with great qualities and Lovely guy', 'team/1599065109-6.jpg'),
(8, 'okodoi oscar', 'Ass chairman', 'The answer: A lot of people. More importantly, though, there&#039;s no way to tell exactly who is reading it &mdash; and you always want it to be ready for when the right people come across it. And when they do, you want it to catch their eye. In a good way.', 'team/1599064959-team1.jpg'),
(9, 'anorld kigame lunganyi', 'majority leader', 'The answer: A lot of people. More importantly, though, there&#039;s no way to tell exactly who is reading it &mdash; and you always want it to be ready for when the right people come across it. And when they do, you want it to catch their eye. In a good way.', 'team/1599064943-team2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `post_content` text NOT NULL,
  `post_date` varchar(255) NOT NULL,
  `post_image` text NOT NULL,
  `post_tags` text NOT NULL,
  `post_status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `author`, `post_content`, `post_date`, `post_image`, `post_tags`, `post_status`) VALUES
(5, 'How Trees Fight Climate Change in Your Communit', 'brian', '<ul>\r\n	<li>\r\n	<p>Neighborhoods with well-shaded streets can be up to&nbsp;6&ndash;10&deg; F&nbsp;cooler than neighborhoods without street trees, reducing the heat-island effect&nbsp;<em>(see illustration below)</em>, and reducing energy needs.&nbsp;<cite>(U.S. Forest Service Center for Urban Forest Research)</cite></p>\r\n	</li>\r\n	<li>\r\n	<p>Shaded parking lots keep automobiles cooler, reducing emissions from fuel tanks and engines, and helping reduce the heat-island effect in communities.&nbsp;<cite>(U.S. Forest Service)</cite></p>\r\n	</li>\r\n</ul>\r\n', 'Wednesday 26 August 2020', 'imgs/1598421384-volunteers.jpg', 'importance, helping', 'Draft'),
(6, '20 Reasons Why We Should Plant Trees', 'brian', '<p>Where would we be without trees? They are a part of our natural global environment, are used to build the very buildings that we live in, and we even write with, eat food from, sit on, and read from products that are made from them.</p>\r\n\r\n<p>Because trees are so important, there are many reasons why we should plant more of them.</p>\r\n', 'Wednesday 26 August 2020', 'imgs/1598421498-love9.jpg', 'importance, helping', 'Published'),
(7, 'Corruption effects | On People, Society &amp;amp; Economy', 'brian', '<p>The impact of corruption on public life can be very hard. It can derange the economy, health, and quality of life. In spite of this, it appears that corruption is ever rising and unstoppable.</p>\r\n\r\n<p>Further, since there are different&nbsp;<a href=\"https://www.mindcontroversy.com/types-corruption-consequences/\">types of corruption</a>, it is hardly easy to escape the corruption effects. This is more of an awkward and defaming condition than being problematic.</p>\r\n\r\n<p>The&nbsp;<a href=\"https://geni.us/politcoruption\" target=\"_blank\">people involved in corruption</a>&nbsp;seem to be proud of themselves as they make more money in a short time. To worst part is that those involved in corruption are able to get better promotions and opportunities than the others.</p>\r\n\r\n<p>The public also has developed an opinion that it is the only way to get their work done. If not, the work will be pending for long or might not even be&nbsp;</p>\r\n', 'Monday 31 August 2020', 'imgs/1598898027-28.jpg', 'corruption', 'Published'),
(10, 'technolgy', ' brian', '<p>Technology means a lot of things these days. The word &quot;technology&quot; brings to mind various devices, such as laptops, phones, and tablets. Technology may also make you think of the internet, data, or advancements in the world of engineering. This may be a narrow scope though, as technology includes so many creative solutions to many everyday problems humans have faced all throughout history. So what is technology?</p>\r\n\r\n<p>Technologies from around the world have been adopted to aid human life, from the most basic inventions, to complex systems that function entirely independently from the human experience. Technology has revolutionized society in countless ways; technology allowed early humans to grow their own food, navigate the open oceans, tell time, and connect society on a global scale. The transition from manual to technological methods of solving problems took place simply because relying on technology makes work easier. This lesson discusses these advancements in technology, and provides an overview of what technology is.</p>\r\n', 'Monday 12 September 2022', 'imgs/1662962347-2021649-Mary-Engelbreit-Quote-Don-t-look-back-you-re-not-going-that-way.jpg', 'technology', 'Published');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_album`
--

CREATE TABLE `tbl_album` (
  `albumid` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `adesc` varchar(1000) NOT NULL,
  `image` varchar(500) NOT NULL,
  `date` datetime NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_album`
--

INSERT INTO `tbl_album` (`albumid`, `name`, `adesc`, `image`, `date`, `status`) VALUES
(1, 'Cars', 'My Cars Album', '13019lexus_lc_500_4k-HD.jpg', '2016-04-06 04:40:24', 'process'),
(2, 'Sunset PIC', 'My Sunset Album ', '21038british_virgin_islands_sunset-wide.jpg', '2016-04-06 04:52:04', 'process'),
(3, '3d wallpaers', 'My 3d wallpaers', '22862solid_abstract_colors-HD.jpg', '2016-04-06 04:54:51', 'process'),
(4, 'Heros', 'Mysuper heros', '4710iron_man_4k-HD.jpg', '2016-04-06 10:27:58', 'process'),
(5, 'Ladscape', 'My extrem ', '6567construction-40.jpg', '2016-04-06 10:28:52', 'delete'),
(6, 'love me', 'hello', '1170979319volunteers.jpg', '2020-08-27 14:25:30', 'delete'),
(7, 'home', 'love', '359079031UWYCE6999.JPG', '2020-08-27 14:25:45', 'delete'),
(8, 'kigame', 'images from cchrismas', '1518534595womenseeds_540_0.jpg', '2020-08-27 14:29:19', 'delete'),
(9, 'kigame', 'awesome lofe', '1253330937women.jpg', '2020-08-28 10:55:28', 'delete'),
(10, 'masa home coming', 'love and unity', '1990652493PHUK9651.JPG', '2020-08-28 21:04:20', 'delete'),
(11, 'kigame  ', 'aweome', '114343517414_3_22.jpg', '2020-08-29 10:56:20', 'delete'),
(12, 'maasai home coming', 'everybody having fun', '1561654684Masai women.JPG', '2020-08-31 13:38:25', 'process'),
(13, 'brian wedding', 'brians hard a weddign', '1651570919download.jpeg', '2020-09-01 09:37:12', 'process');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_gallery`
--

CREATE TABLE `tbl_gallery` (
  `gid` int(11) NOT NULL,
  `aid` int(11) NOT NULL,
  `gname` varchar(1000) NOT NULL,
  `gimages` varchar(1000) NOT NULL,
  `gdate` datetime NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_gallery`
--

INSERT INTO `tbl_gallery` (`gid`, `aid`, `gname`, `gimages`, `gdate`, `status`) VALUES
(16, 1, 'Cars', '1_b.jpg', '2020-08-29 17:29:28', 'delete'),
(17, 1, 'Cars', '014717653423.jpg', '2020-08-29 17:30:34', 'process'),
(18, 1, 'Cars', '010977697104.jpg', '2020-08-29 17:30:59', 'delete'),
(19, 1, 'Cars', '09907084241_b.jpg', '2020-08-29 17:31:10', 'delete'),
(20, 6, 'love me', '0102318147covid.jpeg', '2020-08-29 17:54:24', 'process'),
(21, 6, 'love me', '0103369717VTMY7882.AAE', '2020-08-29 17:54:29', 'delete'),
(22, 6, 'love me', '01331514128volunteers.jpg', '2020-08-29 17:54:35', 'process'),
(23, 6, 'love me', '020100251women.jpg', '2020-08-29 17:54:40', 'process'),
(24, 6, 'love me', '01291253847women.jpg', '2020-08-29 17:54:46', 'process'),
(25, 6, 'love me', '01236166718XYIS2418.MP4', '2020-08-29 17:54:55', 'delete'),
(26, 6, 'love me', '0903674780UWYCE6999.JPG', '2020-08-29 17:55:03', 'process'),
(27, 3, '3d wallpaers', '0119788790514_3_22.jpg', '2020-08-29 21:20:08', 'process'),
(28, 3, '3d wallpaers', '09188784669.jpg', '2020-08-29 21:20:11', 'process'),
(29, 3, '3d wallpaers', '018479284278.jpeg', '2020-08-29 21:20:15', 'process'),
(30, 3, '3d wallpaers', '010950758608.jpeg', '2020-08-29 21:24:43', 'process'),
(31, 3, '3d wallpaers', '06375033221_b.jpg', '2020-08-29 21:24:47', 'process'),
(32, 3, '3d wallpaers', '0123539329SXML9447.AAE', '2020-08-29 21:24:56', 'delete'),
(33, 3, '3d wallpaers', '0850579076SXML9447.AAE', '2020-08-29 21:27:06', 'delete'),
(34, 3, '3d wallpaers', '05946229985.jpg', '2020-08-29 21:28:06', 'process'),
(35, 6, 'love me', '05351462376.jpg', '2020-08-31 09:23:45', 'process'),
(36, 6, 'love me', '053314638.jpeg', '2020-08-31 09:23:53', 'process'),
(37, 6, 'love me', '0848782764.jpg', '2020-08-31 09:24:00', 'process'),
(38, 6, 'love me', '0212511950414_3_22.jpg', '2020-08-31 09:24:59', 'process'),
(39, 6, 'love me', '0324131713mojave_dynamic_16.jpeg', '2020-08-31 09:32:24', 'delete'),
(40, 6, 'love me', '0185973944mojave_dynamic_11.jpeg', '2020-08-31 09:32:34', 'delete'),
(41, 6, 'love me', '0468330912mojave_dynamic_11.jpeg', '2020-08-31 09:32:52', 'delete'),
(42, 1, 'Cars', '0600115723mojave_dynamic_11.jpeg', '2020-08-31 09:33:05', 'delete'),
(43, 1, 'Cars', '01048690238', '2020-08-31 09:33:12', 'delete'),
(44, 1, 'Cars', '01737848495', '2020-08-31 09:33:13', 'delete'),
(45, 1, 'Cars', '01632272355mojave_dynamic_6.jpeg', '2020-08-31 09:43:35', 'delete'),
(46, 1, 'Cars', '0776717977VTMYE7882.JPG', '2020-08-31 10:00:48', 'process'),
(47, 1, 'Cars', '0897762909womentechies.jpg', '2020-08-31 10:00:53', 'process'),
(48, 1, 'Cars', '01926399464index.html', '2020-08-31 11:43:08', 'delete'),
(49, 1, 'Cars', '01577132867Youths.jpg', '2020-08-31 11:47:36', 'process'),
(50, 1, 'Cars', '0803590127VTMY7882.AAE', '2020-08-31 11:47:44', 'delete'),
(51, 6, 'love me', '01042105448mojave_dynamic_1.jpeg', '2020-08-31 13:33:13', 'process'),
(52, 6, 'love me', '01708826124mojave_dynamic_2.jpeg', '2020-08-31 13:33:27', 'delete'),
(53, 6, 'love me', '0798516923mojave_dynamic_12.jpeg', '2020-08-31 13:33:40', 'process'),
(54, 6, 'love me', '01875110206mojave_dynamic_11.jpeg', '2020-08-31 13:33:45', 'delete'),
(55, 6, 'love me', '01258517526mojave_dynamic_7.jpeg', '2020-08-31 13:33:52', 'delete'),
(56, 6, 'love me', '0449399389mojave_dynamic_4.jpeg', '2020-08-31 13:33:57', 'delete'),
(57, 12, 'maasai home coming', '01191756558Masai women.JPG', '2020-08-31 13:41:32', 'process'),
(58, 12, 'maasai home coming', '0877516512Masai-dansen.jpg', '2020-08-31 13:41:37', 'process'),
(59, 12, 'maasai home coming', '0229656777Maasai-.jpg', '2020-08-31 13:41:43', 'process'),
(60, 12, 'maasai home coming', '01018708730Kenya-Masai-Villagers-10-XL.jpg', '2020-08-31 13:41:53', 'process'),
(61, 12, 'maasai home coming', '01862803968Kenya-Masai-Villagers-10-XL.jpg', '2020-08-31 13:41:58', 'process'),
(62, 12, 'maasai home coming', '0558758771go322222.jpg', '2020-08-31 13:42:02', 'process'),
(63, 12, 'maasai home coming', '01141700440download.jpeg', '2020-08-31 13:42:10', 'process'),
(64, 12, 'maasai home coming', '0704049679download.jpeg', '2020-08-31 13:42:17', 'process'),
(65, 12, 'maasai home coming', '0239131327wall-ubuntu_00324576.jpg', '2020-08-31 14:30:06', 'delete'),
(66, 13, 'brian wedding', '06077149827.jpg', '2020-09-01 09:37:57', 'process');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `pasword` varchar(255) NOT NULL,
  `profile_pic` text NOT NULL,
  `permissions` varchar(30) NOT NULL,
  `last_login` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `pasword`, `profile_pic`, `permissions`, `last_login`) VALUES
(5, 'brian kigame ', ' brian', 'briankigame7@gmail.com', '$2y$10$xke7s8Bzscc.M7Czb8NxmOElYfWiIlBm9uSNnC1nbfTc9gqAPJXvm', 'users/profile_pics/Screenshot from 2020-09-11 12-48-56.png', 'Admin', '2022-09-28 13:37:38'),
(8, 'prince joel ', ' prince ', 'prince@yahoo.com', '$2y$10$sHKzyC8pgg9tyiQ6UkeOgecfBuEeKTYguBDxCt8sueSrP6WuWUVYK', 'users/profile_pics/defaults/head_1.png', 'Admin', '2020-09-11 15:31:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_form_infor`
--
ALTER TABLE `contact_form_infor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents`
--
ALTER TABLE `documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_album`
--
ALTER TABLE `tbl_album`
  ADD PRIMARY KEY (`albumid`);

--
-- Indexes for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `contact_form_infor`
--
ALTER TABLE `contact_form_infor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `documents`
--
ALTER TABLE `documents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_album`
--
ALTER TABLE `tbl_album`
  MODIFY `albumid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_gallery`
--
ALTER TABLE `tbl_gallery`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
